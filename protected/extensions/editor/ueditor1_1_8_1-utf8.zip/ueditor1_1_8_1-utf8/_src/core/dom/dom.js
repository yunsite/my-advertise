///import editor.js
//注册命名空间
/**
 * @class baidu.editor.dom
 */
baidu.editor.dom = baidu.editor.dom || {};