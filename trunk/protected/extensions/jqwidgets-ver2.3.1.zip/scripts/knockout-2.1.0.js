// Knockout JavaScript library v2.1.0
// (c) Steven Sanderson - http://knockoutjs.com/
// License: MIT (http://www.opensource.org/licenses/mit-license.php)

(function (window, document, navigator, undefined) {
    function m(w) { throw w; } var n = void 0, p = !0, s = null, t = !1; function A(w) { return function () { return w } }; function E(w) {
        function B(b, c, d) { d && c !== a.k.r(b) && a.k.S(b, c); c !== a.k.r(b) && a.a.va(b, "change") } var a = "undefined" !== typeof w ? w : {}; a.b = function (b, c) { for (var d = b.split("."), f = a, g = 0; g < d.length - 1; g++) f = f[d[g]]; f[d[d.length - 1]] = c }; a.B = function (a, c, d) { a[c] = d }; a.version = "2.1.0"; a.b("version", a.version); a.a = new function () {
            function b(b, c) { if ("input" !== a.a.o(b) || !b.type || "click" != c.toLowerCase()) return t; var e = b.type; return "checkbox" == e || "radio" == e } var c = /^(\s|\u00A0)+|(\s|\u00A0)+$/g, d = {}, f = {}; d[/Firefox\/2/i.test(navigator.userAgent) ?
"KeyboardEvent" : "UIEvents"] = ["keyup", "keydown", "keypress"]; d.MouseEvents = "click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave".split(" "); for (var g in d) { var e = d[g]; if (e.length) for (var h = 0, j = e.length; h < j; h++) f[e[h]] = g } var k = { propertychange: p }, i = function () { for (var a = 3, b = document.createElement("div"), c = b.getElementsByTagName("i"); b.innerHTML = "<\!--[if gt IE " + ++a + "]><i></i><![endif]--\>", c[0]; ); return 4 < a ? a : n } (); return { Ca: ["authenticity_token", /^__RequestVerificationToken(_.*)?$/],
    v: function (a, b) { for (var c = 0, e = a.length; c < e; c++) b(a[c]) }, j: function (a, b) { if ("function" == typeof Array.prototype.indexOf) return Array.prototype.indexOf.call(a, b); for (var c = 0, e = a.length; c < e; c++) if (a[c] === b) return c; return -1 }, ab: function (a, b, c) { for (var e = 0, f = a.length; e < f; e++) if (b.call(c, a[e])) return a[e]; return s }, ba: function (b, c) { var e = a.a.j(b, c); 0 <= e && b.splice(e, 1) }, za: function (b) { for (var b = b || [], c = [], e = 0, f = b.length; e < f; e++) 0 > a.a.j(c, b[e]) && c.push(b[e]); return c }, T: function (a, b) {
        for (var a = a || [], c = [],
e = 0, f = a.length; e < f; e++) c.push(b(a[e])); return c
    }, aa: function (a, b) { for (var a = a || [], c = [], e = 0, f = a.length; e < f; e++) b(a[e]) && c.push(a[e]); return c }, N: function (a, b) { if (b instanceof Array) a.push.apply(a, b); else for (var c = 0, e = b.length; c < e; c++) a.push(b[c]); return a }, extend: function (a, b) { if (b) for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c]); return a }, ga: function (b) { for (; b.firstChild; ) a.removeNode(b.firstChild) }, Ab: function (b) {
        for (var b = a.a.L(b), c = document.createElement("div"), e = 0, f = b.length; e < f; e++) a.F(b[e]),
c.appendChild(b[e]); return c
    }, X: function (b, c) { a.a.ga(b); if (c) for (var e = 0, f = c.length; e < f; e++) b.appendChild(c[e]) }, Na: function (b, c) { var e = b.nodeType ? [b] : b; if (0 < e.length) { for (var f = e[0], d = f.parentNode, g = 0, h = c.length; g < h; g++) d.insertBefore(c[g], f); g = 0; for (h = e.length; g < h; g++) a.removeNode(e[g]) } }, Pa: function (a, b) { 0 <= navigator.userAgent.indexOf("MSIE 6") ? a.setAttribute("selected", b) : a.selected = b }, w: function (a) { return (a || "").replace(c, "") }, Ib: function (b, c) {
        for (var e = [], f = (b || "").split(c), g = 0, d = f.length; g <
d; g++) { var h = a.a.w(f[g]); "" !== h && e.push(h) } return e
    }, Hb: function (a, b) { a = a || ""; return b.length > a.length ? t : a.substring(0, b.length) === b }, eb: function (a, b) { for (var c = "return (" + a + ")", e = 0; e < b; e++) c = "with(sc[" + e + "]) { " + c + " } "; return new Function("sc", c) }, kb: function (a, b) { if (b.compareDocumentPosition) return 16 == (b.compareDocumentPosition(a) & 16); for (; a != s; ) { if (a == b) return p; a = a.parentNode } return t }, fa: function (b) { return a.a.kb(b, b.ownerDocument) }, o: function (a) { return a && a.tagName && a.tagName.toLowerCase() },
    n: function (a, c, e) { var f = i && k[c]; if (!f && "undefined" != typeof jQuery) { if (b(a, c)) var g = e, e = function (a, b) { var c = this.checked; b && (this.checked = b.fb !== p); g.call(this, a); this.checked = c }; jQuery(a).bind(c, e) } else !f && "function" == typeof a.addEventListener ? a.addEventListener(c, e, t) : "undefined" != typeof a.attachEvent ? a.attachEvent("on" + c, function (b) { e.call(a, b) }) : m(Error("Browser doesn't support addEventListener or attachEvent")) }, va: function (a, c) {
        (!a || !a.nodeType) && m(Error("element must be a DOM node when calling triggerEvent"));
        if ("undefined" != typeof jQuery) { var e = []; b(a, c) && e.push({ fb: a.checked }); jQuery(a).trigger(c, e) } else "function" == typeof document.createEvent ? "function" == typeof a.dispatchEvent ? (e = document.createEvent(f[c] || "HTMLEvents"), e.initEvent(c, p, p, window, 0, 0, 0, 0, 0, t, t, t, t, 0, a), a.dispatchEvent(e)) : m(Error("The supplied element doesn't support dispatchEvent")) : "undefined" != typeof a.fireEvent ? (b(a, c) && (a.checked = a.checked !== p), a.fireEvent("on" + c)) : m(Error("Browser doesn't support triggering events"))
    }, d: function (b) {
        return a.la(b) ?
b() : b
    }, Ua: function (b, c, e) { var f = (b.className || "").split(/\s+/), g = 0 <= a.a.j(f, c); if (e && !g) b.className += (f[0] ? " " : "") + c; else if (g && !e) { e = ""; for (g = 0; g < f.length; g++) f[g] != c && (e += f[g] + " "); b.className = a.a.w(e) } }, Qa: function (b, c) { var e = a.a.d(c); if (e === s || e === n) e = ""; "innerText" in b ? b.innerText = e : b.textContent = e; 9 <= i && (b.style.display = b.style.display) }, lb: function (a) { if (9 <= i) { var b = a.style.width; a.style.width = 0; a.style.width = b } }, Eb: function (b, e) { for (var b = a.a.d(b), e = a.a.d(e), c = [], f = b; f <= e; f++) c.push(f); return c },
    L: function (a) { for (var b = [], e = 0, c = a.length; e < c; e++) b.push(a[e]); return b }, tb: 6 === i, ub: 7 === i, ja: i, Da: function (b, e) { for (var c = a.a.L(b.getElementsByTagName("input")).concat(a.a.L(b.getElementsByTagName("textarea"))), f = "string" == typeof e ? function (a) { return a.name === e } : function (a) { return e.test(a.name) }, g = [], d = c.length - 1; 0 <= d; d--) f(c[d]) && g.push(c[d]); return g }, Bb: function (b) { return "string" == typeof b && (b = a.a.w(b)) ? window.JSON && window.JSON.parse ? window.JSON.parse(b) : (new Function("return " + b))() : s }, sa: function (b,
e, c) { ("undefined" == typeof JSON || "undefined" == typeof JSON.stringify) && m(Error("Cannot find JSON.stringify(). Some browsers (e.g., IE < 8) don't support it natively, but you can overcome this by adding a script reference to json2.js, downloadable from http://www.json.org/json2.js")); return JSON.stringify(a.a.d(b), e, c) }, Cb: function (b, e, c) {
    var c = c || {}, f = c.params || {}, g = c.includeFields || this.Ca, d = b; if ("object" == typeof b && "form" === a.a.o(b)) for (var d = b.action, h = g.length - 1; 0 <= h; h--) for (var k = a.a.Da(b, g[h]),
j = k.length - 1; 0 <= j; j--) f[k[j].name] = k[j].value; var e = a.a.d(e), i = document.createElement("form"); i.style.display = "none"; i.action = d; i.method = "post"; for (var z in e) b = document.createElement("input"), b.name = z, b.value = a.a.sa(a.a.d(e[z])), i.appendChild(b); for (z in f) b = document.createElement("input"), b.name = z, b.value = f[z], i.appendChild(b); document.body.appendChild(i); c.submitter ? c.submitter(i) : i.submit(); setTimeout(function () { i.parentNode.removeChild(i) }, 0)
} 
}
        }; a.b("utils", a.a); a.b("utils.arrayForEach", a.a.v);
        a.b("utils.arrayFirst", a.a.ab); a.b("utils.arrayFilter", a.a.aa); a.b("utils.arrayGetDistinctValues", a.a.za); a.b("utils.arrayIndexOf", a.a.j); a.b("utils.arrayMap", a.a.T); a.b("utils.arrayPushAll", a.a.N); a.b("utils.arrayRemoveItem", a.a.ba); a.b("utils.extend", a.a.extend); a.b("utils.fieldsIncludedWithJsonPost", a.a.Ca); a.b("utils.getFormFields", a.a.Da); a.b("utils.postJson", a.a.Cb); a.b("utils.parseJson", a.a.Bb); a.b("utils.registerEventHandler", a.a.n); a.b("utils.stringifyJson", a.a.sa); a.b("utils.range", a.a.Eb);
        a.b("utils.toggleDomNodeCssClass", a.a.Ua); a.b("utils.triggerEvent", a.a.va); a.b("utils.unwrapObservable", a.a.d); Function.prototype.bind || (Function.prototype.bind = function (a) { var c = this, d = Array.prototype.slice.call(arguments), a = d.shift(); return function () { return c.apply(a, d.concat(Array.prototype.slice.call(arguments))) } }); a.a.f = new function () {
            var b = 0, c = "__ko__" + (new Date).getTime(), d = {}; return { get: function (b, c) { var e = a.a.f.getAll(b, t); return e === n ? n : e[c] }, set: function (b, c, e) {
                e === n && a.a.f.getAll(b,
t) === n || (a.a.f.getAll(b, p)[c] = e)
            }, getAll: function (a, g) { var e = a[c]; if (!(e && "null" !== e)) { if (!g) return; e = a[c] = "ko" + b++; d[e] = {} } return d[e] }, clear: function (a) { var b = a[c]; b && (delete d[b], a[c] = s) } 
            }
        }; a.b("utils.domData", a.a.f); a.b("utils.domData.clear", a.a.f.clear); a.a.G = new function () {
            function b(b, c) { var f = a.a.f.get(b, d); f === n && c && (f = [], a.a.f.set(b, d, f)); return f } function c(e) {
                var f = b(e, t); if (f) for (var f = f.slice(0), d = 0; d < f.length; d++) f[d](e); a.a.f.clear(e); "function" == typeof jQuery && "function" == typeof jQuery.cleanData &&
jQuery.cleanData([e]); if (g[e.nodeType]) for (f = e.firstChild; e = f; ) f = e.nextSibling, 8 === e.nodeType && c(e)
            } var d = "__ko_domNodeDisposal__" + (new Date).getTime(), f = { 1: p, 8: p, 9: p }, g = { 1: p, 9: p }; return { wa: function (a, c) { "function" != typeof c && m(Error("Callback must be a function")); b(a, p).push(c) }, Ma: function (c, f) { var g = b(c, t); g && (a.a.ba(g, f), 0 == g.length && a.a.f.set(c, d, n)) }, F: function (b) { if (f[b.nodeType] && (c(b), g[b.nodeType])) { var d = []; a.a.N(d, b.getElementsByTagName("*")); for (var b = 0, j = d.length; b < j; b++) c(d[b]) } },
                removeNode: function (b) { a.F(b); b.parentNode && b.parentNode.removeChild(b) } 
            }
        }; a.F = a.a.G.F; a.removeNode = a.a.G.removeNode; a.b("cleanNode", a.F); a.b("removeNode", a.removeNode); a.b("utils.domNodeDisposal", a.a.G); a.b("utils.domNodeDisposal.addDisposeCallback", a.a.G.wa); a.b("utils.domNodeDisposal.removeDisposeCallback", a.a.G.Ma); (function () {
            a.a.pa = function (b) {
                var c; if ("undefined" != typeof jQuery) {
                    if ((c = jQuery.clean([b])) && c[0]) {
                        for (b = c[0]; b.parentNode && 11 !== b.parentNode.nodeType; ) b = b.parentNode; b.parentNode &&
b.parentNode.removeChild(b)
                    } 
                } else { var d = a.a.w(b).toLowerCase(); c = document.createElement("div"); d = d.match(/^<(thead|tbody|tfoot)/) && [1, "<table>", "</table>"] || !d.indexOf("<tr") && [2, "<table><tbody>", "</tbody></table>"] || (!d.indexOf("<td") || !d.indexOf("<th")) && [3, "<table><tbody><tr>", "</tr></tbody></table>"] || [0, "", ""]; b = "ignored<div>" + d[1] + b + d[2] + "</div>"; for ("function" == typeof window.innerShiv ? c.appendChild(window.innerShiv(b)) : c.innerHTML = b; d[0]--; ) c = c.lastChild; c = a.a.L(c.lastChild.childNodes) } return c
            };
            a.a.Y = function (b, c) { a.a.ga(b); if (c !== s && c !== n) if ("string" != typeof c && (c = c.toString()), "undefined" != typeof jQuery) jQuery(b).html(c); else for (var d = a.a.pa(c), f = 0; f < d.length; f++) b.appendChild(d[f]) } 
        })(); a.b("utils.parseHtmlFragment", a.a.pa); a.b("utils.setHtml", a.a.Y); a.s = function () {
            function b() { return (4294967296 * (1 + Math.random()) | 0).toString(16).substring(1) } function c(b, g) {
                if (b) if (8 == b.nodeType) { var e = a.s.Ja(b.nodeValue); e != s && g.push({ jb: b, yb: e }) } else if (1 == b.nodeType) for (var e = 0, d = b.childNodes, j = d.length; e <
j; e++) c(d[e], g)
            } var d = {}; return { na: function (a) { "function" != typeof a && m(Error("You can only pass a function to ko.memoization.memoize()")); var c = b() + b(); d[c] = a; return "<\!--[ko_memo:" + c + "]--\>" }, Va: function (a, b) { var c = d[a]; c === n && m(Error("Couldn't find any memo with ID " + a + ". Perhaps it's already been unmemoized.")); try { return c.apply(s, b || []), p } finally { delete d[a] } }, Wa: function (b, d) {
                var e = []; c(b, e); for (var h = 0, j = e.length; h < j; h++) {
                    var k = e[h].jb, i = [k]; d && a.a.N(i, d); a.s.Va(e[h].yb, i); k.nodeValue = ""; k.parentNode &&
k.parentNode.removeChild(k)
                } 
            }, Ja: function (a) { return (a = a.match(/^\[ko_memo\:(.*?)\]$/)) ? a[1] : s } 
            }
        } (); a.b("memoization", a.s); a.b("memoization.memoize", a.s.na); a.b("memoization.unmemoize", a.s.Va); a.b("memoization.parseMemoText", a.s.Ja); a.b("memoization.unmemoizeDomNodeAndDescendants", a.s.Wa); a.Ba = { throttle: function (b, c) { b.throttleEvaluation = c; var d = s; return a.h({ read: b, write: function (a) { clearTimeout(d); d = setTimeout(function () { b(a) }, c) } }) }, notify: function (b, c) {
            b.equalityComparer = "always" == c ? A(t) : a.m.fn.equalityComparer;
            return b
        } 
        }; a.b("extenders", a.Ba); a.Sa = function (b, c, d) { this.target = b; this.ca = c; this.ib = d; a.B(this, "dispose", this.A) }; a.Sa.prototype.A = function () { this.sb = p; this.ib() }; a.R = function () { this.u = {}; a.a.extend(this, a.R.fn); a.B(this, "subscribe", this.ta); a.B(this, "extend", this.extend); a.B(this, "getSubscriptionsCount", this.ob) }; a.R.fn = { ta: function (b, c, d) { var d = d || "change", b = c ? b.bind(c) : b, f = new a.Sa(this, b, function () { a.a.ba(this.u[d], f) } .bind(this)); this.u[d] || (this.u[d] = []); this.u[d].push(f); return f }, notifySubscribers: function (b,
c) { c = c || "change"; this.u[c] && a.a.v(this.u[c].slice(0), function (a) { a && a.sb !== p && a.ca(b) }) }, ob: function () { var a = 0, c; for (c in this.u) this.u.hasOwnProperty(c) && (a += this.u[c].length); return a }, extend: function (b) { var c = this; if (b) for (var d in b) { var f = a.Ba[d]; "function" == typeof f && (c = f(c, b[d])) } return c } 
        }; a.Ga = function (a) { return "function" == typeof a.ta && "function" == typeof a.notifySubscribers }; a.b("subscribable", a.R); a.b("isSubscribable", a.Ga); a.U = function () {
            var b = []; return { bb: function (a) { b.push({ ca: a, Aa: [] }) },
                end: function () { b.pop() }, La: function (c) { a.Ga(c) || m(Error("Only subscribable things can act as dependencies")); if (0 < b.length) { var d = b[b.length - 1]; 0 <= a.a.j(d.Aa, c) || (d.Aa.push(c), d.ca(c)) } } 
            }
        } (); var G = { undefined: p, "boolean": p, number: p, string: p }; a.m = function (b) {
            function c() { if (0 < arguments.length) { if (!c.equalityComparer || !c.equalityComparer(d, arguments[0])) c.I(), d = arguments[0], c.H(); return this } a.U.La(c); return d } var d = b; a.R.call(c); c.H = function () { c.notifySubscribers(d) }; c.I = function () {
                c.notifySubscribers(d,
"beforeChange")
            }; a.a.extend(c, a.m.fn); a.B(c, "valueHasMutated", c.H); a.B(c, "valueWillMutate", c.I); return c
        }; a.m.fn = { equalityComparer: function (a, c) { return a === s || typeof a in G ? a === c : t } }; var x = a.m.Db = "__ko_proto__"; a.m.fn[x] = a.m; a.ia = function (b, c) { return b === s || b === n || b[x] === n ? t : b[x] === c ? p : a.ia(b[x], c) }; a.la = function (b) { return a.ia(b, a.m) }; a.Ha = function (b) { return "function" == typeof b && b[x] === a.m || "function" == typeof b && b[x] === a.h && b.pb ? p : t }; a.b("observable", a.m); a.b("isObservable", a.la); a.b("isWriteableObservable",
a.Ha); a.Q = function (b) { 0 == arguments.length && (b = []); b !== s && (b !== n && !("length" in b)) && m(Error("The argument passed when initializing an observable array must be an array, or null, or undefined.")); var c = a.m(b); a.a.extend(c, a.Q.fn); return c }; a.Q.fn = { remove: function (a) { for (var c = this(), d = [], f = "function" == typeof a ? a : function (c) { return c === a }, g = 0; g < c.length; g++) { var e = c[g]; f(e) && (0 === d.length && this.I(), d.push(e), c.splice(g, 1), g--) } d.length && this.H(); return d }, removeAll: function (b) {
    if (b === n) {
        var c = this(),
d = c.slice(0); this.I(); c.splice(0, c.length); this.H(); return d
    } return !b ? [] : this.remove(function (c) { return 0 <= a.a.j(b, c) })
}, destroy: function (a) { var c = this(), d = "function" == typeof a ? a : function (c) { return c === a }; this.I(); for (var f = c.length - 1; 0 <= f; f--) d(c[f]) && (c[f]._destroy = p); this.H() }, destroyAll: function (b) { return b === n ? this.destroy(A(p)) : !b ? [] : this.destroy(function (c) { return 0 <= a.a.j(b, c) }) }, indexOf: function (b) { var c = this(); return a.a.j(c, b) }, replace: function (a, c) {
    var d = this.indexOf(a); 0 <= d && (this.I(),
this()[d] = c, this.H())
} 
}; a.a.v("pop push reverse shift sort splice unshift".split(" "), function (b) { a.Q.fn[b] = function () { var a = this(); this.I(); a = a[b].apply(a, arguments); this.H(); return a } }); a.a.v(["slice"], function (b) { a.Q.fn[b] = function () { var a = this(); return a[b].apply(a, arguments) } }); a.b("observableArray", a.Q); a.h = function (b, c, d) {
    function f() { a.a.v(v, function (a) { a.A() }); v = [] } function g() { var a = h.throttleEvaluation; a && 0 <= a ? (clearTimeout(x), x = setTimeout(e, a)) : e() } function e() {
        if (!l) if (i && w()) u(); else {
            l =
p; try { var b = a.a.T(v, function (a) { return a.target }); a.U.bb(function (c) { var e; 0 <= (e = a.a.j(b, c)) ? b[e] = n : v.push(c.ta(g)) }); for (var e = q.call(c), f = b.length - 1; 0 <= f; f--) b[f] && v.splice(f, 1)[0].A(); i = p; h.notifySubscribers(k, "beforeChange"); k = e } finally { a.U.end() } h.notifySubscribers(k); l = t
        } 
    } function h() { if (0 < arguments.length) j.apply(h, arguments); else return i || e(), a.U.La(h), k } function j() { "function" === typeof o ? o.apply(c, arguments) : m(Error("Cannot write a value to a ko.computed unless you specify a 'write' option. If you wish to read the current value, don't pass any parameters.")) }
    var k, i = t, l = t, q = b; q && "object" == typeof q ? (d = q, q = d.read) : (d = d || {}, q || (q = d.read)); "function" != typeof q && m(Error("Pass a function that returns the value of the ko.computed")); var o = d.write; c || (c = d.owner); var v = [], u = f, r = "object" == typeof d.disposeWhenNodeIsRemoved ? d.disposeWhenNodeIsRemoved : s, w = d.disposeWhen || A(t); if (r) { u = function () { a.a.G.Ma(r, arguments.callee); f() }; a.a.G.wa(r, u); var y = w, w = function () { return !a.a.fa(r) || y() } } var x = s; h.nb = function () { return v.length }; h.pb = "function" === typeof d.write; h.A = function () { u() };
    a.R.call(h); a.a.extend(h, a.h.fn); d.deferEvaluation !== p && e(); a.B(h, "dispose", h.A); a.B(h, "getDependenciesCount", h.nb); return h
}; a.rb = function (b) { return a.ia(b, a.h) }; w = a.m.Db; a.h[w] = a.m; a.h.fn = {}; a.h.fn[w] = a.h; a.b("dependentObservable", a.h); a.b("computed", a.h); a.b("isComputed", a.rb); (function () {
    function b(a, g, e) {
        e = e || new d; a = g(a); if (!("object" == typeof a && a !== s && a !== n && !(a instanceof Date))) return a; var h = a instanceof Array ? [] : {}; e.save(a, h); c(a, function (c) {
            var d = g(a[c]); switch (typeof d) {
                case "boolean": case "number": case "string": case "function": h[c] =
d; break; case "object": case "undefined": var i = e.get(d); h[c] = i !== n ? i : b(d, g, e)
            } 
        }); return h
    } function c(a, b) { if (a instanceof Array) { for (var c = 0; c < a.length; c++) b(c); "function" == typeof a.toJSON && b("toJSON") } else for (c in a) b(c) } function d() { var b = [], c = []; this.save = function (e, d) { var j = a.a.j(b, e); 0 <= j ? c[j] = d : (b.push(e), c.push(d)) }; this.get = function (e) { e = a.a.j(b, e); return 0 <= e ? c[e] : n } } a.Ta = function (c) {
        0 == arguments.length && m(Error("When calling ko.toJS, pass the object you want to convert.")); return b(c, function (b) {
            for (var c =
0; a.la(b) && 10 > c; c++) b = b(); return b
        })
    }; a.toJSON = function (b, c, e) { b = a.Ta(b); return a.a.sa(b, c, e) } 
})(); a.b("toJS", a.Ta); a.b("toJSON", a.toJSON); (function () {
    a.k = { r: function (b) { switch (a.a.o(b)) { case "option": return b.__ko__hasDomDataOptionValue__ === p ? a.a.f.get(b, a.c.options.oa) : b.getAttribute("value"); case "select": return 0 <= b.selectedIndex ? a.k.r(b.options[b.selectedIndex]) : n; default: return b.value } }, S: function (b, c) {
        switch (a.a.o(b)) {
            case "option": switch (typeof c) {
                    case "string": a.a.f.set(b, a.c.options.oa,
n); "__ko__hasDomDataOptionValue__" in b && delete b.__ko__hasDomDataOptionValue__; b.value = c; break; default: a.a.f.set(b, a.c.options.oa, c), b.__ko__hasDomDataOptionValue__ = p, b.value = "number" === typeof c ? c : ""
                } break; case "select": for (var d = b.options.length - 1; 0 <= d; d--) if (a.k.r(b.options[d]) == c) { b.selectedIndex = d; break } break; default: if (c === s || c === n) c = ""; b.value = c
        } 
    } 
    }
})(); a.b("selectExtensions", a.k); a.b("selectExtensions.readValue", a.k.r); a.b("selectExtensions.writeValue", a.k.S); a.g = function () {
    function b(a, b) {
        for (var d =
s; a != d; ) d = a, a = a.replace(c, function (a, c) { return b[c] }); return a
    } var c = /\@ko_token_(\d+)\@/g, d = /^[\_$a-z][\_$a-z0-9]*(\[.*?\])*(\.[\_$a-z][\_$a-z0-9]*(\[.*?\])*)*$/i, f = ["true", "false"]; return { D: [], W: function (c) {
        var e = a.a.w(c); if (3 > e.length) return []; "{" === e.charAt(0) && (e = e.substring(1, e.length - 1)); for (var c = [], d = s, f, k = 0; k < e.length; k++) {
            var i = e.charAt(k); if (d === s) switch (i) { case '"': case "'": case "/": d = k, f = i } else if (i == f && "\\" !== e.charAt(k - 1)) {
                i = e.substring(d, k + 1); c.push(i); var l = "@ko_token_" + (c.length -
1) + "@", e = e.substring(0, d) + l + e.substring(k + 1), k = k - (i.length - l.length), d = s
            } 
        } f = d = s; for (var q = 0, o = s, k = 0; k < e.length; k++) { i = e.charAt(k); if (d === s) switch (i) { case "{": d = k; o = i; f = "}"; break; case "(": d = k; o = i; f = ")"; break; case "[": d = k, o = i, f = "]" } i === o ? q++ : i === f && (q--, 0 === q && (i = e.substring(d, k + 1), c.push(i), l = "@ko_token_" + (c.length - 1) + "@", e = e.substring(0, d) + l + e.substring(k + 1), k -= i.length - l.length, d = s)) } f = []; e = e.split(","); d = 0; for (k = e.length; d < k; d++) q = e[d], o = q.indexOf(":"), 0 < o && o < q.length - 1 ? (i = q.substring(o + 1), f.push({ key: b(q.substring(0,
o), c), value: b(i, c)
        })) : f.push({ unknown: b(q, c) }); return f
    }, ka: function (b) {
        for (var c = "string" === typeof b ? a.g.W(b) : b, h = [], b = [], j, k = 0; j = c[k]; k++) if (0 < h.length && h.push(","), j.key) { var i; a: { i = j.key; var l = a.a.w(i); switch (l.length && l.charAt(0)) { case "'": case '"': break a; default: i = "'" + l + "'" } } j = j.value; h.push(i); h.push(":"); h.push(j); l = a.a.w(j); if (0 <= a.a.j(f, a.a.w(l).toLowerCase()) ? 0 : l.match(d) !== s) 0 < b.length && b.push(", "), b.push(i + " : function(__ko_value) { " + j + " = __ko_value; }") } else j.unknown && h.push(j.unknown);
        c = h.join(""); 0 < b.length && (c = c + ", '_ko_property_writers' : { " + b.join("") + " } "); return c
    }, wb: function (b, c) { for (var d = 0; d < b.length; d++) if (a.a.w(b[d].key) == c) return p; return t }, $: function (b, c, d, f, k) { if (!b || !a.Ha(b)) { if ((b = c()._ko_property_writers) && b[d]) b[d](f) } else (!k || b() !== f) && b(f) } 
    }
} (); a.b("jsonExpressionRewriting", a.g); a.b("jsonExpressionRewriting.bindingRewriteValidators", a.g.D); a.b("jsonExpressionRewriting.parseObjectLiteral", a.g.W); a.b("jsonExpressionRewriting.insertPropertyAccessorsIntoJson",
a.g.ka); (function () {
    function b(a) { return 8 == a.nodeType && (g ? a.text : a.nodeValue).match(e) } function c(a) { return 8 == a.nodeType && (g ? a.text : a.nodeValue).match(h) } function d(a, e) { for (var d = a, f = 1, g = []; d = d.nextSibling; ) { if (c(d) && (f--, 0 === f)) return g; g.push(d); b(d) && f++ } e || m(Error("Cannot find closing comment tag to match: " + a.nodeValue)); return s } function f(a, b) { var c = d(a, b); return c ? 0 < c.length ? c[c.length - 1].nextSibling : a.nextSibling : s } var g = "<\!--test--\>" === document.createComment("test").text, e = g ? /^<\!--\s*ko\s+(.*\:.*)\s*--\>$/ :
/^\s*ko\s+(.*\:.*)\s*$/, h = g ? /^<\!--\s*\/ko\s*--\>$/ : /^\s*\/ko\s*$/, j = { ul: p, ol: p }; a.e = { C: {}, childNodes: function (a) { return b(a) ? d(a) : a.childNodes }, ha: function (c) { if (b(c)) for (var c = a.e.childNodes(c), e = 0, d = c.length; e < d; e++) a.removeNode(c[e]); else a.a.ga(c) }, X: function (c, e) { if (b(c)) { a.e.ha(c); for (var d = c.nextSibling, f = 0, g = e.length; f < g; f++) d.parentNode.insertBefore(e[f], d) } else a.a.X(c, e) }, Ka: function (a, c) { b(a) ? a.parentNode.insertBefore(c, a.nextSibling) : a.firstChild ? a.insertBefore(c, a.firstChild) : a.appendChild(c) },
    Fa: function (a, c, e) { b(a) ? a.parentNode.insertBefore(c, e.nextSibling) : e.nextSibling ? a.insertBefore(c, e.nextSibling) : a.appendChild(c) }, firstChild: function (a) { return !b(a) ? a.firstChild : !a.nextSibling || c(a.nextSibling) ? s : a.nextSibling }, nextSibling: function (a) { b(a) && (a = f(a)); return a.nextSibling && c(a.nextSibling) ? s : a.nextSibling }, Xa: function (a) { return (a = b(a)) ? a[1] : s }, Ia: function (e) {
        if (j[a.a.o(e)]) {
            var d = e.firstChild; if (d) {
                do if (1 === d.nodeType) {
                    var g; g = d.firstChild; var h = s; if (g) {
                        do if (h) h.push(g); else if (b(g)) {
                            var o =
f(g, p); o ? g = o : h = [g]
                        } else c(g) && (h = [g]); while (g = g.nextSibling)
                    } if (g = h) { h = d.nextSibling; for (o = 0; o < g.length; o++) h ? e.insertBefore(g[o], h) : e.appendChild(g[o]) } 
                } while (d = d.nextSibling)
            } 
        } 
    } 
}
})(); a.b("virtualElements", a.e); a.b("virtualElements.allowedBindings", a.e.C); a.b("virtualElements.emptyNode", a.e.ha); a.b("virtualElements.insertAfter", a.e.Fa); a.b("virtualElements.prepend", a.e.Ka); a.b("virtualElements.setDomNodeChildren", a.e.X); (function () {
    a.J = function () { this.cb = {} }; a.a.extend(a.J.prototype, { nodeHasBindings: function (b) {
        switch (b.nodeType) {
            case 1: return b.getAttribute("data-bind") !=
s; case 8: return a.e.Xa(b) != s; default: return t
        } 
    }, getBindings: function (a, c) { var d = this.getBindingsString(a, c); return d ? this.parseBindingsString(d, c) : s }, getBindingsString: function (b) { switch (b.nodeType) { case 1: return b.getAttribute("data-bind"); case 8: return a.e.Xa(b); default: return s } }, parseBindingsString: function (b, c) {
        try { var d = c.$data, d = "object" == typeof d && d != s ? [d, c] : [c], f = d.length, g = this.cb, e = f + "_" + b, h; if (!(h = g[e])) { var j = " { " + a.g.ka(b) + " } "; h = g[e] = a.a.eb(j, f) } return h(d) } catch (k) {
            m(Error("Unable to parse bindings.\nMessage: " +
k + ";\nBindings value: " + b))
        } 
    } 
    }); a.J.instance = new a.J
})(); a.b("bindingProvider", a.J); (function () {
    function b(b, d, e) { for (var h = a.e.firstChild(d); d = h; ) h = a.e.nextSibling(d), c(b, d, e) } function c(c, g, e) { var h = p, j = 1 === g.nodeType; j && a.e.Ia(g); if (j && e || a.J.instance.nodeHasBindings(g)) h = d(g, s, c, e).Gb; h && b(c, g, !j) } function d(b, c, e, d) {
        function j(a) { return function () { return l[a] } } function k() { return l } var i = 0, l, q; a.h(function () {
            var o = e && e instanceof a.z ? e : new a.z(a.a.d(e)), v = o.$data; d && a.Ra(b, o); if (l = ("function" ==
typeof c ? c() : c) || a.J.instance.getBindings(b, o)) {
                if (0 === i) { i = 1; for (var u in l) { var r = a.c[u]; r && 8 === b.nodeType && !a.e.C[u] && m(Error("The binding '" + u + "' cannot be used with virtual elements")); if (r && "function" == typeof r.init && (r = (0, r.init)(b, j(u), k, v, o)) && r.controlsDescendantBindings) q !== n && m(Error("Multiple bindings (" + q + " and " + u + ") are trying to control descendant bindings of the same element. You cannot use these bindings together on the same element.")), q = u } i = 2 } if (2 === i) for (u in l) (r = a.c[u]) && "function" ==
typeof r.update && (0, r.update)(b, j(u), k, v, o)
            } 
        }, s, { disposeWhenNodeIsRemoved: b }); return { Gb: q === n}
    } a.c = {}; a.z = function (b, c) { c ? (a.a.extend(this, c), this.$parentContext = c, this.$parent = c.$data, this.$parents = (c.$parents || []).slice(0), this.$parents.unshift(this.$parent)) : (this.$parents = [], this.$root = b); this.$data = b }; a.z.prototype.createChildContext = function (b) { return new a.z(b, this) }; a.z.prototype.extend = function (b) { var c = a.a.extend(new a.z, this); return a.a.extend(c, b) }; a.Ra = function (b, c) {
        if (2 == arguments.length) a.a.f.set(b,
"__ko_bindingContext__", c); else return a.a.f.get(b, "__ko_bindingContext__")
    }; a.ya = function (b, c, e) { 1 === b.nodeType && a.e.Ia(b); return d(b, c, e, p) }; a.Ya = function (a, c) { (1 === c.nodeType || 8 === c.nodeType) && b(a, c, p) }; a.xa = function (a, b) { b && (1 !== b.nodeType && 8 !== b.nodeType) && m(Error("ko.applyBindings: first parameter should be your view model; second parameter should be a DOM node")); b = b || window.document.body; c(a, b, p) }; a.ea = function (b) { switch (b.nodeType) { case 1: case 8: var c = a.Ra(b); if (c) return c; if (b.parentNode) return a.ea(b.parentNode) } };
    a.hb = function (b) { return (b = a.ea(b)) ? b.$data : n }; a.b("bindingHandlers", a.c); a.b("applyBindings", a.xa); a.b("applyBindingsToDescendants", a.Ya); a.b("applyBindingsToNode", a.ya); a.b("contextFor", a.ea); a.b("dataFor", a.hb)
})(); a.a.v(["click"], function (b) { a.c[b] = { init: function (c, d, f, g) { return a.c.event.init.call(this, c, function () { var a = {}; a[b] = d(); return a }, f, g) } } }); a.c.event = { init: function (b, c, d, f) {
    var g = c() || {}, e; for (e in g) (function () {
        var g = e; "string" == typeof g && a.a.n(b, g, function (b) {
            var e, i = c()[g]; if (i) {
                var l =
d(); try { var q = a.a.L(arguments); q.unshift(f); e = i.apply(f, q) } finally { e !== p && (b.preventDefault ? b.preventDefault() : b.returnValue = t) } l[g + "Bubble"] === t && (b.cancelBubble = p, b.stopPropagation && b.stopPropagation())
            } 
        })
    })()
} 
}; a.c.submit = { init: function (b, c, d, f) { "function" != typeof c() && m(Error("The value for a submit binding must be a function")); a.a.n(b, "submit", function (a) { var e, d = c(); try { e = d.call(f, b) } finally { e !== p && (a.preventDefault ? a.preventDefault() : a.returnValue = t) } }) } }; a.c.visible = { update: function (b, c) {
    var d =
a.a.d(c()), f = "none" != b.style.display; d && !f ? b.style.display = "" : !d && f && (b.style.display = "none")
} 
}; a.c.enable = { update: function (b, c) { var d = a.a.d(c()); d && b.disabled ? b.removeAttribute("disabled") : !d && !b.disabled && (b.disabled = p) } }; a.c.disable = { update: function (b, c) { a.c.enable.update(b, function () { return !a.a.d(c()) }) } }; a.c.value = { init: function (b, c, d) {
    function f() { var e = c(), f = a.k.r(b); a.g.$(e, d, "value", f, p) } var g = ["change"], e = d().valueUpdate; e && ("string" == typeof e && (e = [e]), a.a.N(g, e), g = a.a.za(g)); if (a.a.ja &&
("input" == b.tagName.toLowerCase() && "text" == b.type && "off" != b.autocomplete && (!b.form || "off" != b.form.autocomplete)) && -1 == a.a.j(g, "propertychange")) { var h = t; a.a.n(b, "propertychange", function () { h = p }); a.a.n(b, "blur", function () { if (h) { h = t; f() } }) } a.a.v(g, function (c) { var e = f; if (a.a.Hb(c, "after")) { e = function () { setTimeout(f, 0) }; c = c.substring(5) } a.a.n(b, c, e) })
}, update: function (b, c) {
    var d = "select" === a.a.o(b), f = a.a.d(c()), g = a.k.r(b), e = f != g; 0 === f && (0 !== g && "0" !== g) && (e = p); e && (g = function () { a.k.S(b, f) }, g(), d && setTimeout(g,
0)); d && 0 < b.length && B(b, f, t)
} 
}; a.c.options = { update: function (b, c, d) {
    "select" !== a.a.o(b) && m(Error("options binding applies only to SELECT elements")); for (var f = 0 == b.length, g = a.a.T(a.a.aa(b.childNodes, function (b) { return b.tagName && "option" === a.a.o(b) && b.selected }), function (b) { return a.k.r(b) || b.innerText || b.textContent }), e = b.scrollTop, h = a.a.d(c()); 0 < b.length; ) a.F(b.options[0]), b.remove(0); if (h) {
        d = d(); "number" != typeof h.length && (h = [h]); if (d.optionsCaption) {
            var j = document.createElement("option"); a.a.Y(j,
d.optionsCaption); a.k.S(j, n); b.appendChild(j)
        } for (var c = 0, k = h.length; c < k; c++) { var j = document.createElement("option"), i = "string" == typeof d.optionsValue ? h[c][d.optionsValue] : h[c], i = a.a.d(i); a.k.S(j, i); var l = d.optionsText, i = "function" == typeof l ? l(h[c]) : "string" == typeof l ? h[c][l] : i; if (i === s || i === n) i = ""; a.a.Qa(j, i); b.appendChild(j) } h = b.getElementsByTagName("option"); c = j = 0; for (k = h.length; c < k; c++) 0 <= a.a.j(g, a.k.r(h[c])) && (a.a.Pa(h[c], p), j++); b.scrollTop = e; f && "value" in d && B(b, a.a.d(d.value), p); a.a.lb(b)
    } 
} 
};
        a.c.options.oa = "__ko.optionValueDomData__"; a.c.selectedOptions = { Ea: function (b) { for (var c = [], b = b.childNodes, d = 0, f = b.length; d < f; d++) { var g = b[d], e = a.a.o(g); "option" == e && g.selected ? c.push(a.k.r(g)) : "optgroup" == e && (g = a.c.selectedOptions.Ea(g), Array.prototype.splice.apply(c, [c.length, 0].concat(g))) } return c }, init: function (b, c, d) { a.a.n(b, "change", function () { var b = c(), g = a.c.selectedOptions.Ea(this); a.g.$(b, d, "value", g) }) }, update: function (b, c) {
            "select" != a.a.o(b) && m(Error("values binding applies only to SELECT elements"));
            var d = a.a.d(c()); if (d && "number" == typeof d.length) for (var f = b.childNodes, g = 0, e = f.length; g < e; g++) { var h = f[g]; "option" === a.a.o(h) && a.a.Pa(h, 0 <= a.a.j(d, a.k.r(h))) } 
        } 
        }; a.c.text = { update: function (b, c) { a.a.Qa(b, c()) } }; a.c.html = { init: function () { return { controlsDescendantBindings: p} }, update: function (b, c) { var d = a.a.d(c()); a.a.Y(b, d) } }; a.c.css = { update: function (b, c) { var d = a.a.d(c() || {}), f; for (f in d) if ("string" == typeof f) { var g = a.a.d(d[f]); a.a.Ua(b, f, g) } } }; a.c.style = { update: function (b, c) {
            var d = a.a.d(c() || {}), f;
            for (f in d) if ("string" == typeof f) { var g = a.a.d(d[f]); b.style[f] = g || "" } 
        } 
        }; a.c.uniqueName = { init: function (b, c) { c() && (b.name = "ko_unique_" + ++a.c.uniqueName.gb, (a.a.tb || a.a.ub) && b.mergeAttributes(document.createElement("<input name='" + b.name + "'/>"), t)) } }; a.c.uniqueName.gb = 0; a.c.checked = { init: function (b, c, d) {
            a.a.n(b, "click", function () {
                var f; if ("checkbox" == b.type) f = b.checked; else if ("radio" == b.type && b.checked) f = b.value; else return; var g = c(); "checkbox" == b.type && a.a.d(g) instanceof Array ? (f = a.a.j(a.a.d(g), b.value),
b.checked && 0 > f ? g.push(b.value) : !b.checked && 0 <= f && g.splice(f, 1)) : a.g.$(g, d, "checked", f, p)
            }); "radio" == b.type && !b.name && a.c.uniqueName.init(b, A(p))
        }, update: function (b, c) { var d = a.a.d(c()); "checkbox" == b.type ? b.checked = d instanceof Array ? 0 <= a.a.j(d, b.value) : d : "radio" == b.type && (b.checked = b.value == d) } 
        }; var F = { "class": "className", "for": "htmlFor" }; a.c.attr = { update: function (b, c) {
            var d = a.a.d(c()) || {}, f; for (f in d) if ("string" == typeof f) {
                var g = a.a.d(d[f]), e = g === t || g === s || g === n; e && b.removeAttribute(f); 8 >= a.a.ja &&
f in F ? (f = F[f], e ? b.removeAttribute(f) : b[f] = g) : e || b.setAttribute(f, g.toString())
            } 
        } 
        }; a.c.hasfocus = { init: function (b, c, d) { function f(b) { var e = c(); a.g.$(e, d, "hasfocus", b, p) } a.a.n(b, "focus", function () { f(p) }); a.a.n(b, "focusin", function () { f(p) }); a.a.n(b, "blur", function () { f(t) }); a.a.n(b, "focusout", function () { f(t) }) }, update: function (b, c) { var d = a.a.d(c()); d ? b.focus() : b.blur(); a.a.va(b, d ? "focusin" : "focusout") } }; a.c["with"] = { p: function (b) { return function () { var c = b(); return { "if": c, data: c, templateEngine: a.q.K} } },
            init: function (b, c) { return a.c.template.init(b, a.c["with"].p(c)) }, update: function (b, c, d, f, g) { return a.c.template.update(b, a.c["with"].p(c), d, f, g) } 
        }; a.g.D["with"] = t; a.e.C["with"] = p; a.c["if"] = { p: function (b) { return function () { return { "if": b(), templateEngine: a.q.K} } }, init: function (b, c) { return a.c.template.init(b, a.c["if"].p(c)) }, update: function (b, c, d, f, g) { return a.c.template.update(b, a.c["if"].p(c), d, f, g) } }; a.g.D["if"] = t; a.e.C["if"] = p; a.c.ifnot = { p: function (b) { return function () { return { ifnot: b(), templateEngine: a.q.K} } },
            init: function (b, c) { return a.c.template.init(b, a.c.ifnot.p(c)) }, update: function (b, c, d, f, g) { return a.c.template.update(b, a.c.ifnot.p(c), d, f, g) } 
        }; a.g.D.ifnot = t; a.e.C.ifnot = p; a.c.foreach = { p: function (b) { return function () { var c = a.a.d(b()); return !c || "number" == typeof c.length ? { foreach: c, templateEngine: a.q.K} : { foreach: c.data, includeDestroyed: c.includeDestroyed, afterAdd: c.afterAdd, beforeRemove: c.beforeRemove, afterRender: c.afterRender, templateEngine: a.q.K} } }, init: function (b, c) { return a.c.template.init(b, a.c.foreach.p(c)) },
            update: function (b, c, d, f, g) { return a.c.template.update(b, a.c.foreach.p(c), d, f, g) } 
        }; a.g.D.foreach = t; a.e.C.foreach = p; a.t = function () { }; a.t.prototype.renderTemplateSource = function () { m(Error("Override renderTemplateSource")) }; a.t.prototype.createJavaScriptEvaluatorBlock = function () { m(Error("Override createJavaScriptEvaluatorBlock")) }; a.t.prototype.makeTemplateSource = function (b, c) {
            if ("string" == typeof b) { var c = c || document, d = c.getElementById(b); d || m(Error("Cannot find template with ID " + b)); return new a.l.i(d) } if (1 ==
b.nodeType || 8 == b.nodeType) return new a.l.M(b); m(Error("Unknown template type: " + b))
        }; a.t.prototype.renderTemplate = function (a, c, d, f) { return this.renderTemplateSource(this.makeTemplateSource(a, f), c, d) }; a.t.prototype.isTemplateRewritten = function (a, c) { return this.allowTemplateRewriting === t || !(c && c != document) && this.V && this.V[a] ? p : this.makeTemplateSource(a, c).data("isRewritten") }; a.t.prototype.rewriteTemplate = function (a, c, d) {
            var f = this.makeTemplateSource(a, d), c = c(f.text()); f.text(c); f.data("isRewritten",
p); !(d && d != document) && "string" == typeof a && (this.V = this.V || {}, this.V[a] = p)
        }; a.b("templateEngine", a.t); a.Z = function () {
            function b(b, c, e) {
                for (var b = a.g.W(b), d = a.g.D, j = 0; j < b.length; j++) { var k = b[j].key; if (d.hasOwnProperty(k)) { var i = d[k]; "function" === typeof i ? (k = i(b[j].value)) && m(Error(k)) : i || m(Error("This template engine does not support the '" + k + "' binding within its templates")) } } b = "ko.templateRewriting.applyMemoizedBindingsToNextSibling(function() {             return (function() { return { " + a.g.ka(b) +
" } })()         })"; return e.createJavaScriptEvaluatorBlock(b) + c
            } var c = /(<[a-z]+\d*(\s+(?!data-bind=)[a-z0-9\-]+(=(\"[^\"]*\"|\'[^\']*\'))?)*\s+)data-bind=(["'])([\s\S]*?)\5/gi, d = /<\!--\s*ko\b\s*([\s\S]*?)\s*--\>/g; return { mb: function (b, c, e) { c.isTemplateRewritten(b, e) || c.rewriteTemplate(b, function (b) { return a.Z.zb(b, c) }, e) }, zb: function (a, g) { return a.replace(c, function (a, c, d, f, i, l, q) { return b(q, c, g) }).replace(d, function (a, c) { return b(c, "<\!-- ko --\>", g) }) }, Za: function (b) {
                return a.s.na(function (c,
e) { c.nextSibling && a.ya(c.nextSibling, b, e) })
            } 
            }
        } (); a.b("templateRewriting", a.Z); a.b("templateRewriting.applyMemoizedBindingsToNextSibling", a.Z.Za); (function () {
            a.l = {}; a.l.i = function (a) { this.i = a }; a.l.i.prototype.text = function () { var b = a.a.o(this.i), b = "script" === b ? "text" : "textarea" === b ? "value" : "innerHTML"; if (0 == arguments.length) return this.i[b]; var c = arguments[0]; "innerHTML" === b ? a.a.Y(this.i, c) : this.i[b] = c }; a.l.i.prototype.data = function (b) {
                if (1 === arguments.length) return a.a.f.get(this.i, "templateSourceData_" +
b); a.a.f.set(this.i, "templateSourceData_" + b, arguments[1])
            }; a.l.M = function (a) { this.i = a }; a.l.M.prototype = new a.l.i; a.l.M.prototype.text = function () { if (0 == arguments.length) { var b = a.a.f.get(this.i, "__ko_anon_template__") || {}; b.ua === n && b.da && (b.ua = b.da.innerHTML); return b.ua } a.a.f.set(this.i, "__ko_anon_template__", { ua: arguments[0] }) }; a.l.i.prototype.nodes = function () { if (0 == arguments.length) return (a.a.f.get(this.i, "__ko_anon_template__") || {}).da; a.a.f.set(this.i, "__ko_anon_template__", { da: arguments[0] }) };
            a.b("templateSources", a.l); a.b("templateSources.domElement", a.l.i); a.b("templateSources.anonymousTemplate", a.l.M)
        })(); (function () {
            function b(b, c, d) { for (var f, c = a.e.nextSibling(c); b && (f = b) !== c; ) b = a.e.nextSibling(f), (1 === f.nodeType || 8 === f.nodeType) && d(f) } function c(c, d) { if (c.length) { var f = c[0], g = c[c.length - 1]; b(f, g, function (b) { a.xa(d, b) }); b(f, g, function (b) { a.s.Wa(b, [d]) }) } } function d(a) { return a.nodeType ? a : 0 < a.length ? a[0] : s } function f(b, f, j, k, i) {
                var i = i || {}, l = b && d(b), l = l && l.ownerDocument, q = i.templateEngine ||
g; a.Z.mb(j, q, l); j = q.renderTemplate(j, k, i, l); ("number" != typeof j.length || 0 < j.length && "number" != typeof j[0].nodeType) && m(Error("Template engine must return an array of DOM nodes")); l = t; switch (f) { case "replaceChildren": a.e.X(b, j); l = p; break; case "replaceNode": a.a.Na(b, j); l = p; break; case "ignoreTargetNode": break; default: m(Error("Unknown renderMode: " + f)) } l && (c(j, k), i.afterRender && i.afterRender(j, k.$data)); return j
            } var g; a.ra = function (b) {
                b != n && !(b instanceof a.t) && m(Error("templateEngine must inherit from ko.templateEngine"));
                g = b
            }; a.qa = function (b, c, j, k, i) { j = j || {}; (j.templateEngine || g) == n && m(Error("Set a template engine before calling renderTemplate")); i = i || "replaceChildren"; if (k) { var l = d(k); return a.h(function () { var g = c && c instanceof a.z ? c : new a.z(a.a.d(c)), o = "function" == typeof b ? b(g.$data) : b, g = f(k, i, o, g, j); "replaceNode" == i && (k = g, l = d(k)) }, s, { disposeWhen: function () { return !l || !a.a.fa(l) }, disposeWhenNodeIsRemoved: l && "replaceNode" == i ? l.parentNode : l }) } return a.s.na(function (d) { a.qa(b, c, j, d, "replaceNode") }) }; a.Fb = function (b,
d, g, k, i) { function l(a, b) { c(b, o); g.afterRender && g.afterRender(b, a) } function q(c, d) { var h = "function" == typeof b ? b(c) : b; o = i.createChildContext(a.a.d(c)); o.$index = d; return f(s, "ignoreTargetNode", h, o, g) } var o; return a.h(function () { var b = a.a.d(d) || []; "undefined" == typeof b.length && (b = [b]); b = a.a.aa(b, function (b) { return g.includeDestroyed || b === n || b === s || !a.a.d(b._destroy) }); a.a.Oa(k, b, q, g, l) }, s, { disposeWhenNodeIsRemoved: k }) }; a.c.template = { init: function (b, c) {
    var d = a.a.d(c()); if ("string" != typeof d && !d.name &&
(1 == b.nodeType || 8 == b.nodeType)) d = 1 == b.nodeType ? b.childNodes : a.e.childNodes(b), d = a.a.Ab(d), (new a.l.M(b)).nodes(d); return { controlsDescendantBindings: p}
}, update: function (b, c, d, f, g) {
    c = a.a.d(c()); f = p; "string" == typeof c ? d = c : (d = c.name, "if" in c && (f = f && a.a.d(c["if"])), "ifnot" in c && (f = f && !a.a.d(c.ifnot))); var l = s; "object" === typeof c && "foreach" in c ? l = a.Fb(d || b, f && c.foreach || [], c, b, g) : f ? (g = "object" == typeof c && "data" in c ? g.createChildContext(a.a.d(c.data)) : g, l = a.qa(d || b, g, c, b)) : a.e.ha(b); g = l; (c = a.a.f.get(b, "__ko__templateSubscriptionDomDataKey__")) &&
"function" == typeof c.A && c.A(); a.a.f.set(b, "__ko__templateSubscriptionDomDataKey__", g)
} 
}; a.g.D.template = function (b) { b = a.g.W(b); return 1 == b.length && b[0].unknown || a.g.wb(b, "name") ? s : "This template engine does not support anonymous templates nested within its templates" }; a.e.C.template = p
        })(); a.b("setTemplateEngine", a.ra); a.b("renderTemplate", a.qa); (function () {
            a.a.O = function (b, c, d) {
                if (d === n) return a.a.O(b, c, 1) || a.a.O(b, c, 10) || a.a.O(b, c, Number.MAX_VALUE); for (var b = b || [], c = c || [], f = b, g = c, e = [], h = 0; h <= g.length; h++) e[h] =
[]; for (var h = 0, j = Math.min(f.length, d); h <= j; h++) e[0][h] = h; h = 1; for (j = Math.min(g.length, d); h <= j; h++) e[h][0] = h; for (var j = f.length, k, i = g.length, h = 1; h <= j; h++) { k = Math.max(1, h - d); for (var l = Math.min(i, h + d); k <= l; k++) e[k][h] = f[h - 1] === g[k - 1] ? e[k - 1][h - 1] : Math.min(e[k - 1][h] === n ? Number.MAX_VALUE : e[k - 1][h] + 1, e[k][h - 1] === n ? Number.MAX_VALUE : e[k][h - 1] + 1) } d = b.length; f = c.length; g = []; h = e[f][d]; if (h === n) e = s; else {
                    for (; 0 < d || 0 < f; ) {
                        j = e[f][d]; i = 0 < f ? e[f - 1][d] : h + 1; l = 0 < d ? e[f][d - 1] : h + 1; k = 0 < f && 0 < d ? e[f - 1][d - 1] : h + 1; if (i === n || i < j - 1) i =
h + 1; if (l === n || l < j - 1) l = h + 1; k < j - 1 && (k = h + 1); i <= l && i < k ? (g.push({ status: "added", value: c[f - 1] }), f--) : (l < i && l < k ? g.push({ status: "deleted", value: b[d - 1] }) : (g.push({ status: "retained", value: b[d - 1] }), f--), d--)
                    } e = g.reverse()
                } return e
            } 
        })(); a.b("utils.compareArrays", a.a.O); (function () {
            function b(a) { if (2 < a.length) { for (var b = a[0], c = a[a.length - 1], e = [b]; b !== c; ) { b = b.nextSibling; if (!b) return; e.push(b) } Array.prototype.splice.apply(a, [0, a.length].concat(e)) } } function c(c, f, g, e, h) {
                var j = [], c = a.h(function () {
                    var c = f(g, h) ||
[]; 0 < j.length && (b(j), a.a.Na(j, c), e && e(g, c)); j.splice(0, j.length); a.a.N(j, c)
                }, s, { disposeWhenNodeIsRemoved: c, disposeWhen: function () { return 0 == j.length || !a.a.fa(j[0]) } }); return { xb: j, h: c}
            } a.a.Oa = function (d, f, g, e, h) {
                for (var f = f || [], e = e || {}, j = a.a.f.get(d, "setDomNodeChildrenFromArrayMapping_lastMappingResult") === n, k = a.a.f.get(d, "setDomNodeChildrenFromArrayMapping_lastMappingResult") || [], i = a.a.T(k, function (a) { return a.$a }), l = a.a.O(i, f), f = [], q = 0, o = [], v = 0, i = [], u = s, r = 0, w = l.length; r < w; r++) switch (l[r].status) {
                    case "retained": var y =
k[q]; y.qb(v); v = f.push(y); 0 < y.P.length && (u = y.P[y.P.length - 1]); q++; break; case "deleted": k[q].h.A(); b(k[q].P); a.a.v(k[q].P, function (a) { o.push({ element: a, index: r, value: l[r].value }); u = a }); q++; break; case "added": for (var y = l[r].value, x = a.m(v), v = c(d, g, y, h, x), C = v.xb, v = f.push({ $a: l[r].value, P: C, h: v.h, qb: x }), z = 0, B = C.length; z < B; z++) { var D = C[z]; i.push({ element: D, index: r, value: l[r].value }); u == s ? a.e.Ka(d, D) : a.e.Fa(d, D, u); u = D } h && h(y, C, x)
                } a.a.v(o, function (b) { a.F(b.element) }); g = t; if (!j) {
                    if (e.afterAdd) for (r = 0; r < i.length; r++) e.afterAdd(i[r].element,
i[r].index, i[r].value); if (e.beforeRemove) { for (r = 0; r < o.length; r++) e.beforeRemove(o[r].element, o[r].index, o[r].value); g = p } 
                } if (!g && o.length) for (r = 0; r < o.length; r++) e = o[r].element, e.parentNode && e.parentNode.removeChild(e); a.a.f.set(d, "setDomNodeChildrenFromArrayMapping_lastMappingResult", f)
            } 
        })(); a.b("utils.setDomNodeChildrenFromArrayMapping", a.a.Oa); a.q = function () { this.allowTemplateRewriting = t }; a.q.prototype = new a.t; a.q.prototype.renderTemplateSource = function (b) {
            var c = !(9 > a.a.ja) && b.nodes ? b.nodes() : s;
            if (c) return a.a.L(c.cloneNode(p).childNodes); b = b.text(); return a.a.pa(b)
        }; a.q.K = new a.q; a.ra(a.q.K); a.b("nativeTemplateEngine", a.q); (function () {
            a.ma = function () {
                var a = this.vb = function () { if ("undefined" == typeof jQuery || !jQuery.tmpl) return 0; try { if (0 <= jQuery.tmpl.tag.tmpl.open.toString().indexOf("__")) return 2 } catch (a) { } return 1 } (); this.renderTemplateSource = function (b, f, g) {
                    g = g || {}; 2 > a && m(Error("Your version of jQuery.tmpl is too old. Please upgrade to jQuery.tmpl 1.0.0pre or later.")); var e = b.data("precompiled");
                    e || (e = b.text() || "", e = jQuery.template(s, "{{ko_with $item.koBindingContext}}" + e + "{{/ko_with}}"), b.data("precompiled", e)); b = [f.$data]; f = jQuery.extend({ koBindingContext: f }, g.templateOptions); f = jQuery.tmpl(e, b, f); f.appendTo(document.createElement("div")); jQuery.fragments = {}; return f
                }; this.createJavaScriptEvaluatorBlock = function (a) { return "{{ko_code ((function() { return " + a + " })()) }}" }; this.addTemplate = function (a, b) { document.write("<script type='text/html' id='" + a + "'>" + b + "<\/script>") }; 0 < a && (jQuery.tmpl.tag.ko_code =
{ open: "__.push($1 || '');" }, jQuery.tmpl.tag.ko_with = { open: "with($1) {", close: "} " })
            }; a.ma.prototype = new a.t; var b = new a.ma; 0 < b.vb && a.ra(b); a.b("jqueryTmplTemplateEngine", a.ma)
        })()
    } "function" === typeof require && "object" === typeof exports && "object" === typeof module ? E(module.exports || exports) : "function" === typeof define && define.amd ? define(["exports"], E) : E(window.ko = {}); p;
})(window, document, navigator);